import java.util.Calendar;
import java.util.GregorianCalendar;

public class Staff {
    //staff id (automatically generated - static)
    private String name;
    private String address;
    private GregorianCalendar dateOfBirth;
    private String phoneNumber;
    private String jobTitle;
    private String PPS;

    public Staff(String name, String address, GregorianCalendar dateOfBirth, String phoneNumber, String jobTitle, String PPS) {
        setName(name);
        setAddress(address);
        setDateOfBirth(dateOfBirth);
        setPhoneNumber(phoneNumber);
        setJobTitle(jobTitle);
        setPPS(PPS);
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        if(address == null || address.equals(""))
            throw new IllegalArgumentException("You must enter a valid address!");
        else
            this.address = address;
    }

    public GregorianCalendar getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(GregorianCalendar dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        //could put in code to validate the phone number
        this.phoneNumber = phoneNumber;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getPPS() {
        return PPS;
    }

    public void setPPS(String PPS) {
        this.PPS = PPS;
    }

    @Override
    public String toString() {
        String str = "Name: " + getName() +
                    "Address: " + getAddress() +
                    " Date of Birth: " +
                    " Phone Number: " + getPhoneNumber() +
                    " Job Title: " + getJobTitle() +
                    " PPS: " + getPPS();

        if(dateOfBirth==null)
            str+="No date of birth specified";
        else
            str+=getDateOfBirth().get(Calendar.DATE) + "-" + (getDateOfBirth().get(Calendar.MONTH) +1) +
                "-" + getDateOfBirth().get(Calendar.YEAR);

        return str;

    }
}
