import java.util.GregorianCalendar;

public class YourAccount {

    private String accountName;
    private String homeAddress;
    private String dateOfBirth;
    private int phoneNumber;
    private int accountNumber;
    private int PPS;
    private int bankName;

    public YourAccount(String accountName, String homeAddress, String dateOfBirth, int phoneNumber,
                       int accountNumber, int PPS, int bankName) {

        setAccountName(accountName);
        setHomeAddress(homeAddress);
        setDateOfBirth(dateOfBirth);
        setPhoneNumber(phoneNumber);
        setAccountNumber(accountNumber);
        setPPS(PPS);
        setBankName(bankName);
    }

    public YourAccount(String accountName, String homeAddress, GregorianCalendar gregorianCalendar, String s, String s1, String s2, String bank_of_ireland) {
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getHomeAddress() {
        return homeAddress;
    }

    public void setHomeAddress(String homeAddress) {
        this.homeAddress = homeAddress;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public int getPhoneNumber() { return phoneNumber; }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getAccountNumber() { return accountNumber; }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public int getPPS() { return PPS; }

    public void setPPS(int PPS) { this.PPS = PPS; }

    public int getBankName() { return bankName; }

    public void setBankName(int bankName) {
        this.bankName = bankName;
    }

    @Override
    public String toString() {
        String str= "Account Name: " + getAccountName() + " " +
                "Home Address " + getHomeAddress() + " " +
                "Date of Birth " + getDateOfBirth() + " " +
                "Phone Number " + getPhoneNumber() + " " +
                "Account Number: " + getAccountNumber() + " " +
                "PPS " + getPPS() + " " +
                "Bank Name: " + getBankName();

        return str;
    }
}
