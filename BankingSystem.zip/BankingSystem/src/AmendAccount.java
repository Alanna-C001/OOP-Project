import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AmendAccount {

    private JPanel panel1;
    private JPanel panel2;
    private JButton amendButton;
    private JButton cancelButton;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    private JTextField textField6;

    public AmendAccount() {
        amendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Amended Staff Details!", "Details Amended", JOptionPane.INFORMATION_MESSAGE);
            }

        });
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Cancelled Amendement of Staff Details", "Details Not Amended", JOptionPane.INFORMATION_MESSAGE);
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Amend Staff Details");

        AmendTestStaff gui = new AmendTestStaff();

        gui.getPanel1().setBackground(Color.ORANGE);
        gui.createUIComponents();

        frame.add(gui.getPanel1());

        frame.setSize(400, 400);
        frame.setVisible(true);
    }

    public JPanel getPanel1() {return panel1;}

    private void createUIComponents() {
        textField1.setText("Account Name (Example: Sarah Cronin)");
        textField2.setText("Home Address (Example: Cork City, Cork)");
        textField3.setText("Date of Birth");
        textField4.setText("Phone Number");
        textField5.setText("Account Number (if you forgot your account number please contact your bank");
        textField6.setText("PPS Number");
    }
}
