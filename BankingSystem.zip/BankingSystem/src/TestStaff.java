import java.util.ArrayList;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class TestStaff {
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);

        Staff staff1 = new Staff("Georgina Mooney", "6 Bridge Street,Tipperary",
                new GregorianCalendar(1982, 5, 19), "083-134-5691",
                "Bank Teller", "7938371W");
        Staff staff2 = new Staff("Mable Summers", "Barrack Street, Cork",
                new GregorianCalendar( 1980,  8,  28),  "087-294-197",
                "Bank Teller",  "172693A");
        Staff staff3 = new Staff("Cory Cotton", "13 Barrington Street, Limerick",
                new GregorianCalendar(1978,  2,  12), "083-189-783",
                "Bank Manager Assistant", "827491T");
        Staff staff4 = new Staff("Lorenzo Benson",  "20 Lotamore Park, Mayfield, Cork",
                new GregorianCalendar(1987,  8,  05), "087-923-170",
                "Bank Manager", "4582110I");
        Staff staff5 = new Staff("Leona Everett",  "Main Street, Gowran,Kilkenny",
                new GregorianCalendar( 1973,  4,  24),"087-834-0118",
                "Credit Analyst",  "637291L");
        Staff staff6 = new Staff("Scarlett Harvey",  "2A Vernon Avenue 3, Dublin",
                new GregorianCalendar(1990,  7,  07), "087-322-8710",
                 "Bank Teller", "276610D");

        System.out.println("Adding the staff to an array-list....");
        ArrayList<Staff> allStaff = new ArrayList<>(Arrays.asList(staff1,staff2,staff3,staff4,staff5,staff6));

        System.out.print("Please enter the name of the person you wish to find: ");
        String name = input.nextLine();

        int i = 0;

        for(i=0;i < allStaff.size();i++)
           if(allStaff.get(i).getName().equalsIgnoreCase(name)) {
                System.out.println(" Found: " + name);
                break;
            }
        if(i == allStaff.size());
        System.out.println("This name could not be found");

        System.out.print("\n\nPlease enter the name of the person whose address you wish to amend: ");

        name = input.nextLine();

        for(i=0; i<allStaff.size(); i++)
            if(allStaff.get(i).getName().equalsIgnoreCase(name)) {
                System.out.println("Found: " + name);

                System.out.println("The current address for this person is: " + allStaff.get(i).getAddress());

                System.out.println("\nPlease enter the new address for this person: ");

                String address = input.nextLine();

                allStaff.get(i).setAddress(address);

                break;
            }
        if(i == allStaff.size())
            System.out.println("Name could not be found");

    }
}
