import java.util.ArrayList;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.Scanner;


public class Account {
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);

        YourAccount account1 = new YourAccount("Hailey Butler", "23 Main Street, County Kerry",
                new GregorianCalendar(1999, 4, 30), "083-982-1456", "004",
                "8743711Q", "Bank Of Ireland");
        YourAccount account2 = new YourAccount("Nikki O Hara", "High Street, Killarney, County Kerry",
                new GregorianCalendar(2000, 5, 23), "087-567-9922", "009",
                "2398710W", "Bank Of Ireland");
        YourAccount account3 = new YourAccount("Chris Terrence", "Mallow, County Cork",
                new GregorianCalendar(1995, 9, 02), "087-298-5812", "023",
                "8723491T", "Bank Of Ireland");
        YourAccount account4 = new YourAccount("Quinn Sullivan", "O' Connell Street, County Dublin",
                new GregorianCalendar(2002, 3, 12), "083-829-5721", "033",
                "1287602U", "Bank Of Ireland");

        System.out.println("Adding the staff to an array-list....");
        ArrayList<Staff> allAccount = new ArrayList<>(Arrays.asList(account1, account2, account3,account4));

        System.out.print("Please enter the name of the person you wish to find: ");
        String name = input.nextLine();

        int i = 0;

        for(i=0;i < allAccount.size();i++)
            if(allAccount.get(i).getName().equalsIgnoreCase(name)) {
                System.out.println(" Found: " + name);
                break;
            }
        if(i == allAccount.size());
        System.out.println("This name could not be found");

        System.out.print("\n\nPlease enter the name of the person whose address you wish to amend: ");

        name = input.nextLine();
    }
}
