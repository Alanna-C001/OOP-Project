import javax.swing.*;

public class PPSValidator {

    public static void main(String args[])
    {
        String PPS;

        PPS = JOptionPane.showInputDialog("Please enter a PPS number: ");

        while(!isValidPPS(PPS)) {
            PPS = JOptionPane.showInputDialog("Invalid PPS number, please try again");
        }
    }



    public static boolean isValidPPS(String PPS){
       int j;

       if(PPS.length()==9) {
           for( j=0; j<=8; j++)
               if (!Character.isDigit(PPS.charAt(j)))
                   break;
       if(j == 9)
          if(Character.isLetter(PPS.charAt(9)) || PPS.charAt(9) == 'A' || PPS.charAt(9) == 'Z') {
              int sum = 0;
              int lastCharAsString;

              for (j = 0; j <= 8; j++)
                  sum += Character.getNumericValue(PPS.charAt(j)) * (9 - j);

              if (Character.isDigit(PPS.charAt(9)))
                  lastCharAsString = Character.getNumericValue(PPS.charAt(8));
              else
                  lastCharAsString = 9;
                    return true;

            }
       }
       return false;
    }
}

